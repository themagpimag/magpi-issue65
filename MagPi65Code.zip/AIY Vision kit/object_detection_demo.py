Basic object detection demo:
* Takes an input image and tries to detect person, dog, or cat.
* Draws bounding boxes around detected objects.
* Saves an image with bounding boxes around detected objects.


from __future__ import print_function


import argparse
from PIL import Image
from PIL import ImageDraw


from aiy.vision.bonnet.models.object_detection import ObjectDetection
from aiy.vision.bonnet.models.object_detection import Object
from aiy.vision.bonnet import VisionBonnet




_LABELS = {
    Object.BACKGROUND: 'Background',
    Object.PERSON: 'Person',
    Object.CAT: 'Cat',
    Object.DOG: 'Dog'
}




def _crop_center(img):
  """Crops image central square."""
  width, height = img.size
  size = min(width, height)
  x, y = (width - size) / 2, (height - size) / 2
  return (img.crop((x, y, x + size, y + size)), (x, y))




def _main():
  parser = argparse.ArgumentParser()
  parser.add_argument('--image_path', '-i', dest='image_path')
  parser.add_argument('--output', '-o', dest='output')
  args = parser.parse_args()


  with VisionBonnet() as bonnet:
    model = ObjectDetection()
    image = Image.open(args.image_path)
    square_image, offset = _crop_center(image)
    key = bonnet.load_model(model.descriptor)
    draw = ImageDraw.Draw(image)
    result = bonnet.image_inference(key, square_image)
    objects = model.interpret(result, 0.3, offset)
    bonnet.unload_model(key)
    for i, obj in enumerate(objects):
      print('Object #%d' % i)
      print('  bbox:', obj.bounding_box)
      print('  label:', _LABELS[obj.kind])
      print('  score:', obj.score)
      x, y, width, height = obj.bounding_box
      draw.rectangle([x, y, x + width, y + height], outline='red')
    image.save(args.output)


if __name__ == '__main__':
  _main()