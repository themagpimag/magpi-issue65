Basic face detection demo:
* Takes an input image and tries to detect faces.
* Draws bounding boxes around detected objects.
* Saves an image with bounding boxes around detected objects.




from __future__ import print_function
import argparse
from PIL import Image
from PIL import ImageDraw
from aiy.vision.bonnet import VisionBonnet
from aiy.vision.bonnet.models.face_detection import FaceDetection 


def _main():
  parser = argparse.ArgumentParser()
  parser.add_argument('--image_path', '-i', dest='image_path')
  parser.add_argument('--output', '-o', dest='output')
  args = parser.parse_args()


  with VisionBonnet() as bonnet:
    model = FaceDetection()
    image = Image.open(args.image_path)
    key = bonnet.load_model(model.descriptor)
    draw = ImageDraw.Draw(image)
    faces = model.interpret(bonnet.image_inference(key, image))
    for i, face in enumerate(faces):
      print('Face #%d' % i)
      print('  bbox:', face.bounding_box)
      print('  face_score:', face.face_score)
      print('  joy_score:', face.joy_score)
      x, y, width, height = face.bounding_box
      draw.rectangle([x, y, x + width, y + height], outline='red')
    bonnet.unload_model(key)
    image.save(args.output)


if __name__ == '__main__':
  _main()