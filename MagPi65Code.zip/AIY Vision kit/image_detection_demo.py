Basic image classification demo. Analyzes input image and prints labels and their probabilities.


from __future__ import print_function
import argparse
from PIL import Image
from aiy.vision.bonnet import VisionBonnet
from aiy.vision.bonnet.models.image_classification import ImageClassification


def _main():
  parser = argparse.ArgumentParser()
  parser.add_argument('--image_path', '-i', dest='image_path')
  args = parser.parse_args()


  with VisionBonnet() as bonnet:
    model = ImageClassification()
    image = Image.open(args.image_path)
    key = bonnet.load_model(model.descriptor)
    result = model.interpret(bonnet.image_inference(key, image))
    bonnet.unload_model(key)
    for i in range(len(result)):
      print('Top {} result: {} ({:0.4f} probability)'.format(
          i + 1, result[i][0], result[i][1]))


if __name__ == '__main__':
  _main()